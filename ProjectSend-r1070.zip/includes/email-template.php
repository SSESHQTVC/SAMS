<?php
/**
 * Define the common header and footer markup used on all sent e-mails.
 *
 * @package ProjectSend
 *
 * @deprecated
 */